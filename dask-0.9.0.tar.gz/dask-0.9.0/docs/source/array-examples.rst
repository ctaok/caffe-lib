Examples
========

.. toctree::
   :maxdepth: 1

   examples/array-numpy.rst
   examples/array-hdf5.rst
   examples/array-random.rst
