*  My workers aren't connecting to my Scheduler, what can I do?
    *  Check that you have specified your hostname correctly and that your
      workers can ping your hostname.  You may want to try using IP addresses
      directly.
