Examples
========

.. toctree::
   :maxdepth: 1

   examples/delayed-array.rst
   examples/delayed-custom.rst
