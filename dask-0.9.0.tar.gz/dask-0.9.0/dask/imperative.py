from warnings import warn

from .delayed import do, value, Delayed, Value, delayed

warn("dask.imperative has been moved to dask.delayed")
